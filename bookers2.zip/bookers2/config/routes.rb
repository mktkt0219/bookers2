Rails.application.routes.draw do
  devise_for :users
  root to: 'home#top'
  get  "home/about"  => "home#about"

    devise_scope :user do
    get '/users/sign_out' => 'devise/sessions#destroy'
  end

  resources :users
  resources :books
end
