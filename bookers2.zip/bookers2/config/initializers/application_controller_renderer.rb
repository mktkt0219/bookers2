# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '3053bbe21b2abc15481eec4f59f98206e7278025c5fa2e85452bf0cc4f867314f6fd20630c913854014395a42431a03f6e852ff8673a187b057365fa21d1c9f8'